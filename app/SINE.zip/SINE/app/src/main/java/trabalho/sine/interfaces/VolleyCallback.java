package trabalho.sine.interfaces;

/**
 * Created by wagner on 08/12/16.
 */

public interface VolleyCallback {
    void onSuccess(String response);
}
